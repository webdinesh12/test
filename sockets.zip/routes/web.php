<?php

use App\Http\Controllers\HomeController;
use Illuminate\Support\Facades\Route;

Route::get('/', [HomeController::class, 'index'])->name('home');
Route::get('/1', [HomeController::class, 'index1']);
Route::get('/event', [HomeController::class, 'event']);
Route::get('/event2', [HomeController::class, 'event2']);
Route::get('/eventall', [HomeController::class, 'allEvent']);
Route::get('/2', [HomeController::class, 'index2']);

Route::get('/fake-login', [HomeController::class, 'fakeLogin']);

Route::get('/upload-image', [HomeController::class, 'uploadImage']);
Route::post('/upload-image', [HomeController::class, 'doUploadImage']);
Route::get('/upload-file', [HomeController::class, 'uploadFiles']);
Route::post('/upload-file', [HomeController::class, 'doUploadFiles']);
Route::get('/test', [HomeController::class, 'test']);
Route::get('/send-mail', [HomeController::class, 'sendMail']);
Route::post('/send-mail', [HomeController::class, 'doSendMail']);

Route::get('/reset-password', [HomeController::class, 'resetPassword']);
Route::post('/reset-password', [HomeController::class, 'doResetPassword']);

Route::get('/change-status', [HomeController::class, 'changeStatus'])->name('change.status');
Route::get('/change-status2', [HomeController::class, 'changeStatus2'])->name('change.status2');


Route::get('/the-test', [HomeController::class, 'test']);
Route::get('/notification', [HomeController::class, 'notification']);


Route::get('/quote', [HomeController::class, 'quote'])->name('quote');
Route::post('/add-quote', [HomeController::class, 'addQuote'])->name('add.quote');

Route::get('/scroll', [HomeController::class, 'scroll']);
Route::get('/encDes', [HomeController::class, 'encDes']);

Route::get('/history-management', [HomeController::class, 'historyManagement']);
Route::get('/history-management/{name}', [HomeController::class, 'historyManagement']);

Route::get('count/{name}', [HomeController::class, 'count']);
Route::get('dsa', [HomeController::class, 'rotatingArrayFromKPosition']);

Route::get('update-status', [HomeController::class, 'updateStatus']);
Route::post('update-status', [HomeController::class, 'doUpdateStatus']);