<?php

namespace App\Repositary\Stripe;

interface  StripeRepo{
	// Write instensable functions
	public function test();
}