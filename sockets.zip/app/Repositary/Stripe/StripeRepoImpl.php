<?php

namespace App\Repositary\Stripe;

use Illuminate\Support\Facades\Log;

class StripeRepoImpl implements  StripeRepo{
	// Write implements functions
	public function test(){
		Log::info('Test');
	}
}