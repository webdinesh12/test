<?php

namespace App\Repositary\CustomRepo;

interface CustomRepo{
    public function logCustomRepo();
}