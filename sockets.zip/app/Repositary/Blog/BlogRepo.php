<?php

namespace App\Repositary\Blog;

interface BlogRepo{
    public function writeLog();
}